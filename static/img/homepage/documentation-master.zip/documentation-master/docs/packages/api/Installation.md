---
id: installation
title: Installation
sidebar_label: Installation
slug: /api/installation
---

The `api` package can be installed over [npm](https://www.npmjs.com/).

```bash npm2yarn
npm install @agile-ts/api 
```
