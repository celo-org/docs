---
id: docsearch
title: DocSearch
sidebar_label: DocSearch
slug: /docsearch
---

Hello `docsearch` Team,

As you can see I am the maintainer of this documentation
and have the rights to edit it ^^

With best regards

BennoDev
