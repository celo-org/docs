---
id: md-playground 
title: Playground 
sidebar_label: Playground 
slug: /md/playground
---

:::note

**bold**
_italic_
[ling](https://google.com)

:::

:::caution

**bold**
_italic_
[link](https://google.com)

:::

:::important

**bold**
_italic_
[link](https://google.com)

:::

:::danger

**bold**
_italic_
[link](https://google.com)

:::

:::success

**bold**
_italic_
[link](https://google.com)

:::

:::tip

**bold**
_italic_
[link](https://google.com)

:::

:::secondary

**bold**
_italic_
[link](https://google.com)

:::