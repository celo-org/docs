export interface GetGithubStatsInterface {
  stars: number;
  forks: number;
}
