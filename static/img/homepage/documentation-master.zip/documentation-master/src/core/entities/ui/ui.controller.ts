import { createState } from '@agile-ts/core';

export const ASTRONAUT_DARK = createState<boolean>(false);
