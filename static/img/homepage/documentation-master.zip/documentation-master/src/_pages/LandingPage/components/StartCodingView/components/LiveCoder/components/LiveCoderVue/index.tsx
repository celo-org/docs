// The options I tried doesn't work at all or not at expected
// Tried:
// https://github.com/vue-styleguidist/vue-live // [Webpack error: 'webpack < 5 used to include polyfills for node.js core modules by default.']
// https://github.com/QingWei-Li/vuep // Looks weired and doesn't work at all
// https://medium.com/@pateldhruv020/using-vue-component-in-react-9161f30d29a0
// https://github.com/akxcv/vuera // Used to use the `vuep` Component in React and does it Job
